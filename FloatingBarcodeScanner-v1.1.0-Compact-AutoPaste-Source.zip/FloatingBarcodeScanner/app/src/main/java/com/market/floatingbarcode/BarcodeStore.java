package com.market.floatingbarcode;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

/** All barcodes are stored as strings, preserving leading zeroes. */
public final class BarcodeStore {
    private static final String PREFS = "barcode_settings";
    private static final String LAST = "last_code";
    private static final String HISTORY = "history";
    private static final String COLLAPSE = "auto_collapse";
    private static final String BUBBLE = "bubble_size";
    private static final String AUTO_PASTE = "accessibility_auto_paste";

    private BarcodeStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String getLast(Context context) { return prefs(context).getString(LAST, ""); }
    public static boolean isAutoCollapse(Context context) { return prefs(context).getBoolean(COLLAPSE, true); }
    public static void setAutoCollapse(Context context, boolean value) { prefs(context).edit().putBoolean(COLLAPSE, value).apply(); }
    public static boolean isAutoPaste(Context context) { return prefs(context).getBoolean(AUTO_PASTE, true); }
    public static void setAutoPaste(Context context, boolean value) { prefs(context).edit().putBoolean(AUTO_PASTE, value).apply(); }
    // A much smaller collapsed bubble is permitted; the camera preview is unaffected.
    public static int getBubbleDp(Context context) { return Math.max(26, Math.min(100, prefs(context).getInt(BUBBLE, 42))); }
    public static void setBubbleDp(Context context, int size) { prefs(context).edit().putInt(BUBBLE, Math.max(26, Math.min(100, size))).apply(); }

    public static List<String> getHistory(Context context) {
        List<String> values = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(prefs(context).getString(HISTORY, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String item = array.optString(i, "");
                if (!TextUtils.isEmpty(item)) values.add(item);
            }
        } catch (JSONException ignored) { }
        return values;
    }

    public static void save(Context context, String code) {
        if (TextUtils.isEmpty(code)) return;
        List<String> history = getHistory(context);
        history.remove(code);
        history.add(0, code);
        JSONArray array = new JSONArray();
        for (int i = 0; i < Math.min(30, history.size()); i++) array.put(history.get(i));
        prefs(context).edit().putString(LAST, code).putString(HISTORY, array.toString()).apply();
    }

    public static void clearHistory(Context context) {
        prefs(context).edit().remove(LAST).putString(HISTORY, "[]").apply();
    }
}
