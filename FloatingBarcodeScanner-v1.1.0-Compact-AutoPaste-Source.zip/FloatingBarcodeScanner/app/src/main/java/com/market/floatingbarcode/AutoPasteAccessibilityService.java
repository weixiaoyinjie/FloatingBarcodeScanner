package com.market.floatingbarcode;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Optional, explicitly user-enabled service. Barcode values never leave the device.
 * Only performs an edit when FloatingScanService asks, not on accessibility events.
 */
public final class AutoPasteAccessibilityService extends AccessibilityService {
    private static volatile AutoPasteAccessibilityService connected;
    private final Handler main = new Handler(Looper.getMainLooper());
    private static final int MAX_DEPTH = 18;
    private static final int MAX_NODES = 250;

    public interface ResultCallback { void onResult(boolean success); }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        connected = this;
    }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { /* No monitoring or logging. */ }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() {
        if (connected == this) connected = null;
        main.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    /** Settings alone cannot grant the permission; user must enable our service manually. */
    public static boolean isEnabled(Context context) {
        String enabled = Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        String expected = context.getPackageName() + "/" + AutoPasteAccessibilityService.class.getName();
        for (String part : enabled.split(":")) {
            if (part.equalsIgnoreCase(expected) ||
                    part.equalsIgnoreCase(context.getPackageName() + "/.AutoPasteAccessibilityService")) return true;
        }
        return false;
    }

    public static void fill(Context context, String code, ResultCallback callback) {
        AutoPasteAccessibilityService service = connected;
        if (service == null || !BarcodeStore.isAutoPaste(context) || !code.matches("[0-9]+")) {
            callback.onResult(false);
            return;
        }
        service.fillNow(code, callback, false, 0);
    }

    private void fillNow(String code, ResultCallback callback, boolean alreadyClickedSearch, int retryCount) {
        if (connected != this) { callback.onResult(false); return; }
        Candidate best = new Candidate();
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (isTargetRoot(root)) collect(root, 0, new int[]{0}, best);

        // Overlay is FLAG_NOT_FOCUSABLE. On some Android versions another window
        // (keyboard/system overlay) is "active", so examine application windows as well.
        List<AccessibilityWindowInfo> windows = getWindows();
        if (windows != null) {
            for (AccessibilityWindowInfo win : windows) {
                if (win.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                AccessibilityNodeInfo r = win.getRoot();
                if (isTargetRoot(r)) collect(r, 0, new int[]{0}, best);
            }
        }

        // A focused field is the user's explicit target. Otherwise require a search
        // hint, or exactly one editable field in the foreground application.
        if (best.edit != null && (best.score >= 75 || best.editableCount == 1)) {
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, code);
            boolean success = best.edit.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            if (!success) {
                // Some apps expose paste but not ACTION_SET_TEXT. Clipboard is already
                // updated by the scanner, so paste after focusing the selected field.
                best.edit.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
                CharSequence previous = best.edit.getText();
                if (TextUtils.isEmpty(previous)) {
                    success = best.edit.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                } else {
                    Bundle selection = new Bundle();
                    selection.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0);
                    selection.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, previous.length());
                    if (best.edit.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selection)) {
                        success = best.edit.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                    }
                }
            }
            callback.onResult(success);
        } else if (!alreadyClickedSearch && best.searchClick != null &&
                best.searchClick.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            // E.g. web-based store management: tapping the search bar opens an EditText.
            main.postDelayed(() -> fillNow(code, callback, true, 0), 550);
        } else if (alreadyClickedSearch && retryCount == 0) {
            // Wait once more for search pages rendered asynchronously by WebView.
            main.postDelayed(() -> fillNow(code, callback, true, 1), 650);
        } else {
            callback.onResult(false);
        }
    }

    private boolean isTargetRoot(AccessibilityNodeInfo node) {
        if (node == null || node.getPackageName() == null) return false;
        String pkg = node.getPackageName().toString();
        return !pkg.equals(getPackageName()) &&
                !pkg.equals("com.android.systemui") &&
                !pkg.equals("android") &&
                !pkg.contains("inputmethod") &&
                !pkg.contains("keyboard");
    }

    private void collect(AccessibilityNodeInfo node, int depth, int[] visited, Candidate best) {
        if (node == null || depth > MAX_DEPTH || ++visited[0] > MAX_NODES) return;
        boolean editable = node.isEditable() ||
                (node.getClassName() != null && node.getClassName().toString().contains("EditText"));
        if (editable && node.isEnabled() && !node.isPassword()) {
            if (!best.seenEdits.contains(node)) {
                best.seenEdits.add(node);
                best.editableCount++;
            }
            int score = 20;
            if (node.isFocused()) score += 100;  // Always prioritize input chosen by the user.
            String tags = toSafeString(node.getViewIdResourceName()) + " " +
                    toSafeString(node.getContentDescription()) + " " + toSafeString(node.getText());
            if (Build.VERSION.SDK_INT >= 26) tags += " " + toSafeString(node.getHintText());
            if (isSearchLabel(tags)) score += 55;
            if (score > best.score) { best.edit = node; best.score = score; }
        } else if (!editable && node.isEnabled()) {
            String tags = toSafeString(node.getViewIdResourceName()) + " " +
                    toSafeString(node.getContentDescription()) + " " + toSafeString(node.getText());
            if (isSearchLabel(tags) && best.searchClick == null) {
                AccessibilityNodeInfo clickable = node;
                for (int ancestor = 0; ancestor < 4 && clickable != null; ancestor++) {
                    if (clickable.isClickable() && clickable.isEnabled()) {
                        best.searchClick = clickable;
                        break;
                    }
                    clickable = clickable.getParent();
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            collect(node.getChild(i), depth + 1, visited, best);
            if (visited[0] >= MAX_NODES) break;
        }
    }

    private static boolean isSearchLabel(String text) {
        String t = text.toLowerCase(Locale.ROOT);
        return t.contains("search") || t.contains("buscar") || t.contains("busqueda") ||
                t.contains("búsqueda") || t.contains("barcode") || t.contains("codigo") ||
                t.contains("código") || t.contains("sku") || t.contains("producto") ||
                t.contains("条码") || t.contains("商品") || t.contains("搜索") ||
                t.contains("搜寻") || t.contains("放大镜");
    }

    private static String toSafeString(Object o) { return o == null ? "" : o.toString(); }

    private static final class Candidate {
        AccessibilityNodeInfo edit;
        AccessibilityNodeInfo searchClick;
        int score = -1;
        int editableCount = 0;
        List<AccessibilityNodeInfo> seenEdits = new ArrayList<>();
    }
}
