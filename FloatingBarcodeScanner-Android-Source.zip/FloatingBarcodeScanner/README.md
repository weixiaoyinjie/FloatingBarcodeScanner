# 悬浮条码助手 · Floating Barcode Scanner

一个用 **Java + CameraX + Google ML Kit（随包离线模型）** 编写的免费安卓悬浮条形码识别 APP。

## 核心功能

- **悬浮小按钮**：切换至收银、库存或价格管理等其他应用时仍显示在屏幕上，单击展开摄像头，拖动即可移动。
- **悬浮实时摄像头**：在其他应用上方直接扫描纸质条形码；窗口顶部拖动移动，右下角拖动调整宽高。
- **识别即自动复制**：复制条码里的完整**数字字符串**，不丢失开头的 `0`，扫码后默认 0.85 秒自动缩回小按钮。
- **快速粘贴**：在目标应用输入框长按 → 粘贴即可。
- **自定义尺寸**：主页可修改悬浮按钮尺寸，扫码窗可直接拖动大小；可以关闭扫码后自动缩小选项。
- **扫描记录**：本机保存最新 30 条数字条码；可轻触历史条码重新复制，支持清空。
- **更多操作**：补光灯、重新扫描、手动重新复制、缩小悬浮窗、彻底关闭悬浮服务。

支持 EAN-13、EAN-8、UPC-A、UPC-E、CODE-128、CODE-39、CODE-93、ITF 和 CODABAR 等条码。为了避免把字母或复杂文本误当商品编码，**只复制纯数字扫描结果**。不包括 OCR/截图文本识别。

## 免费 API / 隐私

使用官方 `com.google.mlkit:barcode-scanning:17.3.0` **bundled 本地模型**。没有开发者 API Key，没有服务端接口、数据库订阅或按次收费；安装后不需要互联网（应用未申请 INTERNET 权限）。相机帧只送到手机本机 ML Kit 模型；条码历史保存在手机 App 私有 SharedPreferences 中，且不会备份。页面不含广告。

## 安卓版本与权限

- Android 6.0+ (`minSdk 23`)，目标 Android 14 (`targetSdk 34`)
- 需要 **摄像头** 和 **显示在其他应用上层** 权限。
- Android 13+ 会请求通知权限，以便在通知栏显示前台扫码服务（拒绝通知权限一般不影响前台服务启动，通知可受系统限制）。
- 使用 `camera|specialUse` 类型的前台服务；需要在 APP 主界面可见时启动一次。 Android 14+ 禁止在后台随意新建摄像头前台服务，因此不做开机自动启动；在通知栏或悬浮面板关闭服务后，要回 APP 启动。
- 某些手机厂商的省电管理可能自动停止后台服务；可在手机电池/应用管理里手动允许 APP 在后台运行。
- 录制与上传视频：**无**。摄像头开启仅用于实时条码识别，最小化窗口时取消 CameraX 绑定并停止读取帧。
- 关闭悬浮窗方法：在悬浮扫描窗点 `×`、主界面点“停止悬浮扫码”，或通知栏点“停止”。

## 如何运行 / 获取 APK

### 方案 A：在 GitHub 免费构建 APK（推荐）

1. 在 GitHub 创建**新仓库**，把此 ZIP **解压后的全部文件**上传到仓库根目录，保留 `.github/workflows/build-apk.yml` 文件。
2. 打开仓库的 **Actions** → **Build Android APK** → **Run workflow**。也可直接推送到 `main` 分支触发构建。
3. 构建成功后打开该次运行 → **Artifacts** → `FloatingBarcodeScanner-debug-apk`，下载压缩包，解压后获得 `app-debug.apk`。
4. 将 APK 发送到安卓手机安装；如有提示，允许当前文件管理器安装未知来源应用。APK 为调试签名，适合自己手机测试使用。

> `.github` 是隐藏目录。如果上传时丢失或没有触发 Actions，请在仓库确认路径为 `.github/workflows/build-apk.yml`，且仓库允许使用 GitHub Actions。

### 方案 B：Android Studio

1. **Open** 打开根目录 `FloatingBarcodeScanner/`，使用 JDK 17 及 Gradle 8.9。
2. 同步 Gradle，安装 Android SDK Platform 35 和 Build Tools 35.0.0。
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**。
4. 生成的调试包通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

本工程未附带 Gradle Wrapper JAR，可用 Android Studio 配置 Gradle 8.9，或使用 GitHub Actions 中的 `gradle/actions/setup-gradle@v4` 安装 Gradle 8.9。

## 使用步骤

1. 安装后打开【悬浮条码助手】 → 【开启悬浮扫码】。
2. 按屏幕提示给予悬浮显示和相机权限；启动成功后会显示蓝色悬浮按钮。
3. 切换到另一个 App，例如库存管理；点击悬浮按钮，在悬浮相机窗口内对准商品条码。
4. 当扫描到纯数字条码时，**自动复制**，并会短暂显示已复制提示，默认自动缩小悬浮窗。
5. 点击目标 App 的输入框，长按后选择【粘贴】。下一件商品重复第 3–5 步。

## 代码结构

- `app/src/main/java/com/market/floatingbarcode/MainActivity.java`：主页面、权限、最近历史、悬浮按钮尺寸与设置。
- `app/src/main/java/com/market/floatingbarcode/FloatingScanService.java`：安卓摄像头前台服务、悬浮窗口拖拽缩放、ML Kit 连续扫码、剪贴板。
- `app/src/main/java/com/market/floatingbarcode/BarcodeStore.java`：本地字符串型条码历史、设置。
- `app/src/main/java/com/market/floatingbarcode/Ui.java`：原生控件视觉工具。
- `.github/workflows/build-apk.yml`：自动编译、生成 APK 的免费 GitHub Actions 工作流。

## 关于发布

个人侧载安装不需要发布到商店。如计划将 APP 上架 Google Play，摄像头前台服务与 `specialUse` 类型等均需遵守当期商店政策，必要时调整对应前台服务类型的申报与审核内容。
