package com.market.floatingbarcode;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

final class Ui {
    static final int NAVY = Color.rgb(11, 20, 39);
    static final int PANEL = Color.rgb(21, 34, 55);
    static final int BLUE = Color.rgb(65, 130, 248);
    static final int CYAN = Color.rgb(62, 225, 199);
    static final int MUTED = Color.rgb(162, 179, 205);
    static final int WHITE = Color.WHITE;

    static int dp(Context ctx, float dp) {
        return (int) (ctx.getResources().getDisplayMetrics().density * dp + .5f);
    }

    static GradientDrawable rounded(int color, float radiusDp, Context ctx) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(ctx, radiusDp));
        return d;
    }

    static GradientDrawable bordered(int color, float radiusDp, int strokeColor, Context ctx) {
        GradientDrawable d = rounded(color, radiusDp, ctx);
        d.setStroke(dp(ctx, 1), strokeColor);
        return d;
    }

    static GradientDrawable gradient(Context ctx) {
        GradientDrawable d = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR, new int[] { Color.rgb(58, 139, 247), Color.rgb(32, 188, 186) });
        d.setCornerRadius(dp(ctx, 20));
        return d;
    }

    static TextView text(Context ctx, String text, int sp, int color, boolean bold) {
        TextView tv = new TextView(ctx);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setGravity(Gravity.CENTER_VERTICAL);
        tv.setIncludeFontPadding(true);
        return tv;
    }

    static TextView button(Context ctx, String text, int color, int textColor) {
        TextView tv = text(ctx, text, 14, textColor, true);
        tv.setGravity(Gravity.CENTER);
        tv.setBackground(rounded(color, 13, ctx));
        tv.setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12));
        tv.setClickable(true);
        return tv;
    }

    static ViewGroup.MarginLayoutParams margin(ViewGroup.LayoutParams base, int left, int top, int right, int bottom) {
        ViewGroup.MarginLayoutParams m = new ViewGroup.MarginLayoutParams(base);
        m.setMargins(left, top, right, bottom);
        return m;
    }
    private Ui() {}
}
