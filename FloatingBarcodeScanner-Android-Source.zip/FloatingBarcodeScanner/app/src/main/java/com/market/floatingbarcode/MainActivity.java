package com.market.floatingbarcode;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public final class MainActivity extends Activity {
    private static final int REQ_CAMERA = 500;
    private boolean pendingStart = false;
    private TextView startButton, permissionText, lastCode, historyTitle;
    private LinearLayout historyItems;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.NAVY);
        getWindow().setNavigationBarColor(Ui.NAVY);
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Ui.NAVY);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(Ui.dp(this, 22), Ui.dp(this, 30), Ui.dp(this, 22), Ui.dp(this, 38));
        scroll.addView(body);
        setContentView(scroll);

        TextView kicker = Ui.text(this, "FREE  ·  OFFLINE  ·  NO API KEY", 11, Ui.CYAN, true);
        body.addView(kicker);
        TextView title = Ui.text(this, "悬浮条码助手", 29, Ui.WHITE, true);
        addGap(body, 9); body.addView(title);
        TextView subtitle = Ui.text(this, "扫码即复制，不用来回切换应用", 14, Ui.MUTED, false);
        addGap(body, 7); body.addView(subtitle);

        LinearLayout hero = card();
        hero.setBackground(Ui.gradient(this));
        addGap(body, 28); body.addView(hero);
        TextView heroIcon = Ui.text(this, "▥   一扫 · 一复制", 23, Color.WHITE, true);
        hero.addView(heroIcon);
        addGap(hero, 7);
        TextView heroLine = Ui.text(this, "悬浮摄像头可拖动、自由调尺寸。扫码成功后完整保留数字和前导 0，自动进入剪贴板。", 13, Color.WHITE, false);
        heroLine.setLineSpacing(Ui.dp(this, 2), 1f);
        hero.addView(heroLine);

        addGap(body, 25);
        body.addView(Ui.text(this, "01  开始使用", 16, Ui.WHITE, true));
        addGap(body, 12);
        LinearLayout controls = card(); body.addView(controls);
        permissionText = Ui.text(this, "正在检查权限…", 12, Ui.MUTED, false);
        controls.addView(permissionText);
        addGap(controls, 15);
        startButton = Ui.button(this, "开启悬浮扫码", Ui.BLUE, Ui.WHITE);
        controls.addView(startButton);
        startButton.setOnClickListener(v -> {
            if (FloatingScanService.running) stopScanner(); else requestStart();
        });
        addGap(controls, 10);
        TextView tip = Ui.text(this, "第一次使用需允许相机和“在其他应用上层显示”。启动后可直接切换到收银或库存应用。", 12, Ui.MUTED, false);
        tip.setLineSpacing(Ui.dp(this, 2), 1.05f);
        controls.addView(tip);

        addGap(body, 25);
        body.addView(Ui.text(this, "02  悬浮设置", 16, Ui.WHITE, true));
        addGap(body, 12);
        LinearLayout config = card(); body.addView(config);
        Switch collapseSwitch = new Switch(this);
        collapseSwitch.setText("扫码成功后自动缩小");
        collapseSwitch.setTextSize(14);
        collapseSwitch.setTextColor(Ui.WHITE);
        collapseSwitch.setChecked(BarcodeStore.isAutoCollapse(this));
        collapseSwitch.setOnCheckedChangeListener((v, checked) -> BarcodeStore.setAutoCollapse(this, checked));
        config.addView(collapseSwitch);
        addGap(config, 15);
        TextView bubbleTitle = Ui.text(this, "悬浮小按钮尺寸", 14, Ui.WHITE, true);
        config.addView(bubbleTitle);
        SeekBar sizeBar = new SeekBar(this);
        sizeBar.setMax(52);
        sizeBar.setProgress(BarcodeStore.getBubbleDp(this) - 48);
        config.addView(sizeBar);
        TextView sizeText = Ui.text(this, BarcodeStore.getBubbleDp(this) + " dp   ·   扫描窗口右下角也可拖动缩放", 12, Ui.MUTED, false);
        config.addView(sizeText);
        sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int dp = 48 + progress;
                sizeText.setText(dp + " dp   ·   扫描窗口右下角也可拖动缩放");
                if (!fromUser) return;
                BarcodeStore.setBubbleDp(MainActivity.this, dp);
                if (FloatingScanService.running) {
                    Intent intent = new Intent(MainActivity.this, FloatingScanService.class);
                    intent.setAction(FloatingScanService.ACTION_RESIZE_BUBBLE);
                    startService(intent);
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });

        addGap(body, 25);
        body.addView(Ui.text(this, "03  最近一次条码", 16, Ui.WHITE, true));
        addGap(body, 12);
        LinearLayout lastCard = card(); body.addView(lastCard);
        lastCode = Ui.text(this, "尚未扫描", 22, Ui.CYAN, true);
        lastCode.setTextIsSelectable(true);
        lastCard.addView(lastCode);
        addGap(lastCard, 12);
        TextView copyLast = Ui.button(this, "再次复制号码", Ui.PANEL, Ui.WHITE);
        copyLast.setBackground(Ui.bordered(Ui.PANEL, 13, Ui.BLUE, this));
        lastCard.addView(copyLast);
        copyLast.setOnClickListener(v -> {
            String code = BarcodeStore.getLast(this);
            if (code.isEmpty()) Toast.makeText(this, "还没有已扫描的号码", Toast.LENGTH_SHORT).show();
            else copy(code);
        });

        addGap(body, 25);
        historyTitle = Ui.text(this, "扫描记录", 16, Ui.WHITE, true);
        body.addView(historyTitle);
        addGap(body, 12);
        historyItems = card(); body.addView(historyItems);
        TextView clear = Ui.button(this, "清空本机记录", Ui.NAVY, Ui.MUTED);
        addGap(body, 12); body.addView(clear);
        clear.setOnClickListener(v -> {
            BarcodeStore.clearHistory(this);
            refresh();
        });
        addGap(body, 18);
        TextView footer = Ui.text(this, "条码识别在手机上完成，无需联网或付费 API。仅接受纯数字条码，防止将字母条码误当商品码。", 11, Ui.MUTED, false);
        footer.setGravity(Gravity.CENTER);
        footer.setLineSpacing(Ui.dp(this, 3), 1f);
        body.addView(footer);
        refresh();
    }

    private LinearLayout card() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setPadding(Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18));
        v.setBackground(Ui.rounded(Ui.PANEL, 20, this));
        return v;
    }

    private void addGap(LinearLayout parent, int dp) {
        View gap = new View(this);
        parent.addView(gap, new LinearLayout.LayoutParams(1, Ui.dp(this, dp)));
    }

    private void refresh() {
        if (startButton == null) return;
        boolean hasOverlay = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        boolean hasCamera = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
        permissionText.setText("悬浮窗 " + (hasOverlay ? "✓ 已授权" : "○ 待授权") + "   ·   相机 " + (hasCamera ? "✓ 已授权" : "○ 待授权"));
        startButton.setText(FloatingScanService.running ? "停止悬浮扫码" : "开启悬浮扫码");
        startButton.setBackground(Ui.rounded(FloatingScanService.running ? Color.rgb(169, 64, 83) : Ui.BLUE, 13, this));
        String latest = BarcodeStore.getLast(this);
        lastCode.setText(latest.isEmpty() ? "尚未扫描" : latest);
        List<String> history = BarcodeStore.getHistory(this);
        historyTitle.setText("扫描记录  ·  " + history.size() + " 条");
        historyItems.removeAllViews();
        if (history.isEmpty()) {
            historyItems.addView(Ui.text(this, "扫描的号码会保存在这里", 13, Ui.MUTED, false));
        } else {
            for (int i = 0; i < history.size(); i++) {
                String code = history.get(i);
                TextView item = Ui.text(this, (i + 1) + "     " + code + "     复制 ↗", 15, Ui.WHITE, i == 0);
                item.setPadding(0, Ui.dp(this, 9), 0, Ui.dp(this, 9));
                item.setOnClickListener(v -> copy(code));
                historyItems.addView(item);
            }
        }
    }

    private void copy(String value) {
        ClipboardManager mgr = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        mgr.setPrimaryClip(ClipData.newPlainText("条形码", value));
        Toast.makeText(this, "已复制：" + value, Toast.LENGTH_SHORT).show();
    }

    private void requestStart() {
        pendingStart = true;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(intent);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            }
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
            return;
        }
        startNow();
    }

    private void startNow() {
        pendingStart = false;
        Intent intent = new Intent(this, FloatingScanService.class);
        intent.setAction(FloatingScanService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent);
            else startService(intent);
            Toast.makeText(this, "悬浮扫码已启动，切换到其他应用即可使用", Toast.LENGTH_LONG).show();
            new Handler(Looper.getMainLooper()).postDelayed(this::refresh, 600);
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 501);
            }
        } catch (RuntimeException e) {
            Toast.makeText(this, "无法启动悬浮窗：" + e.getMessage(), Toast.LENGTH_LONG).show();
            refresh();
        }
    }

    private void stopScanner() {
        pendingStart = false;
        Intent intent = new Intent(this, FloatingScanService.class);
        intent.setAction(FloatingScanService.ACTION_STOP);
        startService(intent);
        new Handler(Looper.getMainLooper()).postDelayed(this::refresh, 300);
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
        if (pendingStart && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (!isFinishing() && pendingStart) requestStart();
            }, 250);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA && pendingStart) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) startNow();
            else {
                pendingStart = false;
                Toast.makeText(this, "摄像头权限是扫码所必需的", Toast.LENGTH_LONG).show();
            }
        }
        refresh();
    }
}
