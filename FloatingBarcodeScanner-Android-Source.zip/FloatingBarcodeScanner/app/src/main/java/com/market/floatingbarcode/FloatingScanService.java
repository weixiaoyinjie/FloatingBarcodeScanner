package com.market.floatingbarcode;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Size;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** A camera foreground service with a movable, resizable TYPE_APPLICATION_OVERLAY scan panel. */
public final class FloatingScanService extends Service implements LifecycleOwner {
    public static final String ACTION_START = "com.market.floatingbarcode.START";
    public static final String ACTION_STOP = "com.market.floatingbarcode.STOP";
    public static final String ACTION_RESIZE_BUBBLE = "com.market.floatingbarcode.RESIZE_BUBBLE";
    public static volatile boolean running = false;

    private static final int NOTIFICATION_ID = 72;
    private static final String CHANNEL = "floating_scan_camera";
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean processing = new AtomicBoolean(false);
    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private View overlayView;
    private PreviewView previewView;
    private TextView statusView, resultView, torchButton;
    private BarcodeScanner scanner;
    private ProcessCameraProvider cameraProvider;
    private Camera camera;
    private ExecutorService analysisExecutor;
    private LifecycleRegistry lifecycleRegistry;
    private boolean panelOpen = false;
    private volatile boolean acceptingFrames = false;
    private boolean torchOn = false;
    private boolean copiedSuccessfully = false;
    private int panelWidth, panelHeight;
    private String lastResult = "";

    @Override public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        analysisExecutor = Executors.newSingleThreadExecutor();
        lifecycleRegistry = new LifecycleRegistry(this);
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE);
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START);
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME);

        BarcodeScannerOptions options = new BarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                        Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                        Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E,
                        Barcode.FORMAT_CODE_128, Barcode.FORMAT_CODE_39,
                        Barcode.FORMAT_CODE_93, Barcode.FORMAT_ITF,
                        Barcode.FORMAT_CODABAR)
                .build();
        scanner = BarcodeScanning.getClient(options);
        panelWidth = Ui.dp(this, 315);
        panelHeight = Ui.dp(this, 440);
        createChannel();
    }

    @Override public Lifecycle getLifecycle() { return lifecycleRegistry; }
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_RESIZE_BUBBLE.equals(action) && running) {
            if (!panelOpen) showBubble();
            return START_NOT_STICKY;
        }
        if (Build.VERSION.SDK_INT >= 23 && (!Settings.canDrawOverlays(this) ||
                checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!running) {
            startCameraForeground();
            running = true;
        }
        if (overlayView == null) showBubble();
        return START_NOT_STICKY;
    }

    private void startCameraForeground() {
        Notification n = notification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA | ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "悬浮条码扫码", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("显示正在运行的悬浮摄像头，可随时停止");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification notification() {
        Intent launch = new Intent(this, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent open = PendingIntent.getActivity(this, 0, launch, pendingFlags);
        Intent stopIntent = new Intent(this, FloatingScanService.class).setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 1, stopIntent, pendingFlags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("悬浮条码助手正在运行")
                .setContentText("点击悬浮按钮开始扫码 · 识别后自动复制")
                .setContentIntent(open)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_delete, "停止", stop)
                .build();
    }

    private int screenWidth() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        return metrics.widthPixels;
    }
    private int screenHeight() {
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        return metrics.heightPixels;
    }
    private WindowManager.LayoutParams layoutParams(int width, int height) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                width, height,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                android.graphics.PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = params == null ? screenWidth() - width - Ui.dp(this, 12) : params.x;
        p.y = params == null ? Ui.dp(this, 130) : params.y;
        p.x = Math.max(0, Math.min(p.x, screenWidth() - width));
        p.y = Math.max(Ui.dp(this, 26), Math.min(p.y, screenHeight() - height - Ui.dp(this, 14)));
        return p;
    }

    private void detachCurrent() {
        acceptingFrames = false;
        if (cameraProvider != null) cameraProvider.unbindAll();
        camera = null;
        torchOn = false;
        previewView = null;
        statusView = null;
        resultView = null;
        torchButton = null;
        if (overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (IllegalArgumentException ignored) {}
        }
        overlayView = null;
    }

    private void showBubble() {
        detachCurrent();
        panelOpen = false;
        int dimension = Ui.dp(this, BarcodeStore.getBubbleDp(this));
        FrameLayout bubble = new FrameLayout(this);
        bubble.setBackground(Ui.gradient(this));
        bubble.setElevation(Ui.dp(this, 9));
        TextView symbol = Ui.text(this, copiedSuccessfully ? "✓" : "▥", 29, Color.WHITE, true);
        symbol.setGravity(Gravity.CENTER);
        bubble.addView(symbol, new FrameLayout.LayoutParams(-1, -1));
        bubble.setContentDescription("悬浮扫码按钮，点击展开相机，长按拖动");
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float startRawX, startRawY;
            int startX, startY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (params == null) return false;
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startRawX = e.getRawX(); startRawY = e.getRawY();
                        startX = params.x; startY = params.y; moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - startRawX;
                        float dy = e.getRawY() - startRawY;
                        if (Math.abs(dx) > Ui.dp(FloatingScanService.this, 6) ||
                                Math.abs(dy) > Ui.dp(FloatingScanService.this, 6)) moved = true;
                        if (moved) moveWindow(startX + (int)dx, startY + (int)dy);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) showPanel();
                        return true;
                    case MotionEvent.ACTION_CANCEL: return true;
                }
                return false;
            }
        });
        params = layoutParams(dimension, dimension);
        overlayView = bubble;
        try { windowManager.addView(bubble, params); }
        catch (RuntimeException e) { stopSelf(); }
    }

    private void showPanel() {
        detachCurrent();
        panelOpen = true;
        copiedSuccessfully = false;
        lastResult = ""; // Allow repeated scans of the same product barcode.
        acceptingFrames = false;
        int maxW = screenWidth() - Ui.dp(this, 10);
        int maxH = screenHeight() - Ui.dp(this, 80);
        panelWidth = Math.min(panelWidth, maxW);
        panelHeight = Math.min(panelHeight, maxH);
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 10));
        panel.setBackground(Ui.bordered(Ui.PANEL, 20, Ui.BLUE, this));
        panel.setElevation(Ui.dp(this, 12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(this, "≡  悬浮扫码", 16, Ui.WHITE, true);
        title.setPadding(Ui.dp(this, 6), Ui.dp(this, 7), 0, Ui.dp(this, 7));
        header.addView(title, new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1));
        title.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (params == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = event.getRawX(); downY = event.getRawY();
                        startX = params.x; startY = params.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        moveWindow(startX + (int)(event.getRawX() - downX),
                                startY + (int)(event.getRawY() - downY));
                        return true;
                    case MotionEvent.ACTION_UP: return true;
                }
                return false;
            }
        });
        TextView minimize = Ui.button(this, "—", Color.rgb(35, 54, 77), Ui.WHITE);
        header.addView(minimize, new LinearLayout.LayoutParams(Ui.dp(this, 41), Ui.dp(this, 40)));
        minimize.setOnClickListener(v -> showBubble());
        TextView exit = Ui.button(this, "×", Color.rgb(112, 47, 64), Ui.WHITE);
        LinearLayout.LayoutParams exitP = new LinearLayout.LayoutParams(Ui.dp(this, 41), Ui.dp(this, 40));
        exitP.leftMargin = Ui.dp(this, 7);
        header.addView(exit, exitP);
        exit.setOnClickListener(v -> stopSelf());
        panel.addView(header);

        FrameLayout cameraFrame = new FrameLayout(this);
        cameraFrame.setBackground(Ui.rounded(Color.rgb(6, 14, 25), 14, this));
        cameraFrame.setClipToOutline(true);
        LinearLayout.LayoutParams cameraParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        cameraParams.topMargin = Ui.dp(this, 10);
        panel.addView(cameraFrame, cameraParams);
        PreviewView preview = new PreviewView(this);
        preview.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        cameraFrame.addView(preview, new FrameLayout.LayoutParams(-1, -1));
        cameraFrame.addView(new ScanGuide(this), new FrameLayout.LayoutParams(-1, -1));
        previewView = preview;

        statusView = Ui.text(this, "请将条形码对准镜头…", 12, Ui.MUTED, false);
        statusView.setSingleLine(true);
        LinearLayout.LayoutParams statusP = new LinearLayout.LayoutParams(-1, Ui.dp(this, 31));
        statusP.topMargin = Ui.dp(this, 6);
        panel.addView(statusView, statusP);
        resultView = Ui.text(this, "等待识别", 20, Ui.CYAN, true);
        resultView.setSingleLine(true);
        resultView.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        panel.addView(resultView, new LinearLayout.LayoutParams(-1, Ui.dp(this, 37)));

        LinearLayout actions = new LinearLayout(this);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        TextView repeat = Ui.button(this, "重新扫描", Ui.BLUE, Ui.WHITE);
        actions.addView(repeat, new LinearLayout.LayoutParams(0, Ui.dp(this, 45), 1));
        repeat.setOnClickListener(v -> {
            lastResult = "";
            resultView.setText("等待识别");
            statusView.setText("请将条形码对准镜头…");
            acceptingFrames = true;
        });
        TextView copy = Ui.button(this, "复制", Color.rgb(35, 54, 77), Ui.WHITE);
        LinearLayout.LayoutParams copyP = new LinearLayout.LayoutParams(Ui.dp(this, 65), Ui.dp(this, 45));
        copyP.leftMargin = Ui.dp(this, 8);
        actions.addView(copy, copyP);
        copy.setOnClickListener(v -> {
            String code = resultView.getText().toString();
            if (code.matches("[0-9]+")) copyCode(code);
            else statusView.setText("请先扫描数字条形码");
        });
        torchButton = Ui.button(this, "闪光灯", Color.rgb(35, 54, 77), Ui.WHITE);
        LinearLayout.LayoutParams lightP = new LinearLayout.LayoutParams(Ui.dp(this, 75), Ui.dp(this, 45));
        lightP.leftMargin = Ui.dp(this, 8);
        actions.addView(torchButton, lightP);
        torchButton.setOnClickListener(v -> toggleTorch());
        LinearLayout.LayoutParams actionP = new LinearLayout.LayoutParams(-1, Ui.dp(this, 45));
        actionP.topMargin = Ui.dp(this, 3);
        panel.addView(actions, actionP);

        LinearLayout footer = new LinearLayout(this);
        footer.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        TextView hint = Ui.text(this, "拖动顶部移动  ·  右下角缩放", 10, Ui.MUTED, false);
        footer.addView(hint, new LinearLayout.LayoutParams(0, Ui.dp(this, 35), 1));
        TextView grip = Ui.text(this, "◢", 25, Ui.CYAN, true);
        grip.setGravity(Gravity.RIGHT | Gravity.BOTTOM);
        footer.addView(grip, new LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 35)));
        grip.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int width, height;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        width = params.width; height = params.height; return true;
                    case MotionEvent.ACTION_MOVE:
                        resizePanel(width + (int)(e.getRawX() - downX),
                                height + (int)(e.getRawY() - downY));
                        return true;
                    case MotionEvent.ACTION_UP: return true;
                }
                return false;
            }
        });
        panel.addView(footer);

        params = layoutParams(panelWidth, panelHeight);
        overlayView = panel;
        try {
            windowManager.addView(panel, params);
            bindCamera();
        } catch (RuntimeException e) {
            stopSelf();
        }
    }

    private void moveWindow(int x, int y) {
        if (params == null || overlayView == null) return;
        params.x = Math.max(0, Math.min(x, Math.max(0, screenWidth() - params.width)));
        params.y = Math.max(Ui.dp(this, 26), Math.min(y, Math.max(Ui.dp(this, 26), screenHeight() - params.height)));
        try { windowManager.updateViewLayout(overlayView, params); }
        catch (RuntimeException ignored) { }
    }

    private void resizePanel(int width, int height) {
        if (!panelOpen || params == null || overlayView == null) return;
        int minW = Ui.dp(this, 260), minH = Ui.dp(this, 335);
        int maxW = Math.max(minW, screenWidth() - params.x - Ui.dp(this, 4));
        int maxH = Math.max(minH, screenHeight() - params.y - Ui.dp(this, 4));
        params.width = Math.max(minW, Math.min(width, maxW));
        params.height = Math.max(minH, Math.min(height, maxH));
        panelWidth = params.width;
        panelHeight = params.height;
        try { windowManager.updateViewLayout(overlayView, params); }
        catch (RuntimeException ignored) { }
    }

    private void bindCamera() {
        if (previewView == null || !panelOpen) return;
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            if (!panelOpen || previewView == null || !running) return;
            try {
                cameraProvider = future.get();
                cameraProvider.unbindAll();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setTargetResolution(new Size(1280, 720))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analysis.setAnalyzer(analysisExecutor, this::analyzeFrame);
                camera = cameraProvider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis);
                acceptingFrames = true;
                if (statusView != null) statusView.setText("摄像头已开启 · 自动识别商品数字条码");
            } catch (Exception e) {
                acceptingFrames = false;
                if (statusView != null) statusView.setText("无法打开摄像头，请关闭其他相机应用");
            }
        }, command -> main.post(command));
    }

    @androidx.camera.core.ExperimentalGetImage
    private void analyzeFrame(ImageProxy proxy) {
        if (!panelOpen || !acceptingFrames || !processing.compareAndSet(false, true)) {
            proxy.close();
            return;
        }
        android.media.Image image = proxy.getImage();
        if (image == null) {
            processing.set(false);
            proxy.close();
            return;
        }
        InputImage input = InputImage.fromMediaImage(image, proxy.getImageInfo().getRotationDegrees());
        try {
            scanner.process(input)
                .addOnSuccessListener(barcodes -> {
                    if (!panelOpen || !acceptingFrames) return;
                    for (Barcode barcode : barcodes) {
                        String code = barcode.getRawValue();
                        if (code == null || code.isEmpty()) continue;
                        if (!code.matches("[0-9]+")) continue;
                        if (code.equals(lastResult)) continue;
                        acceptingFrames = false;
                        lastResult = code;
                        onBarcodeDetected(code);
                        break;
                    }
                })
                .addOnFailureListener(e -> {
                    if (statusView != null && panelOpen) statusView.setText("识别失败，调整距离再试");
                })
                .addOnCompleteListener(task -> {
                    proxy.close();
                    processing.set(false);
                });
        } catch (RuntimeException e) {
            processing.set(false);
            proxy.close();
        }
    }

    private void onBarcodeDetected(String code) {
        if (!panelOpen || statusView == null || resultView == null) return;
        resultView.setText(code);
        statusView.setText("识别成功 · 正在自动复制…");
        copyCode(code);
    }

    private void copyCode(String code) {
        if (!code.matches("[0-9]+")) return;
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("条形码号码", code));
            BarcodeStore.save(this, code);
            copiedSuccessfully = true;
            if (statusView != null) statusView.setText("✓ 已自动复制：可到其他应用长按粘贴");
            vibrate();
            if (panelOpen && BarcodeStore.isAutoCollapse(this)) {
                main.postDelayed(() -> {
                    if (running && panelOpen && code.equals(lastResult)) showBubble();
                }, 850);
            }
        } catch (RuntimeException e) {
            if (statusView != null) statusView.setText("自动复制失败，请点击复制重试");
        }
    }

    private void vibrate() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(90, VibrationEffect.DEFAULT_AMPLITUDE));
        else vibrator.vibrate(90);
    }

    private void toggleTorch() {
        if (camera == null || !camera.getCameraInfo().hasFlashUnit()) {
            if (statusView != null) statusView.setText("该摄像头没有闪光灯");
            return;
        }
        torchOn = !torchOn;
        camera.getCameraControl().enableTorch(torchOn);
        if (torchButton != null) torchButton.setText(torchOn ? "关灯" : "闪光灯");
    }

    @Override public void onDestroy() {
        running = false;
        acceptingFrames = false;
        main.removeCallbacksAndMessages(null);
        detachCurrent();
        if (scanner != null) scanner.close();
        if (analysisExecutor != null) analysisExecutor.shutdown();
        if (lifecycleRegistry != null) {
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE);
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP);
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY);
        }
        super.onDestroy();
    }

    /** Camera overlay viewfinder decoration; the transparent center shows the preview. */
    private static final class ScanGuide extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ScanGuide(Service c) { super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w = getWidth(), h = getHeight();
            float left = w * .09f, top = h * .33f;
            float right = w * .91f, bottom = h * .67f;
            paint.setColor(0x337FFFFF);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Ui.dp(getContext(), 1));
            canvas.drawRoundRect(new RectF(left, top, right, bottom), 11, 11, paint);
            paint.setColor(Ui.CYAN);
            paint.setStrokeWidth(Ui.dp(getContext(), 4));
            float arm = Ui.dp(getContext(), 19);
            canvas.drawLine(left, top, left + arm, top, paint);
            canvas.drawLine(left, top, left, top + arm, paint);
            canvas.drawLine(right, top, right - arm, top, paint);
            canvas.drawLine(right, top, right, top + arm, paint);
            canvas.drawLine(left, bottom, left + arm, bottom, paint);
            canvas.drawLine(left, bottom, left, bottom - arm, paint);
            canvas.drawLine(right, bottom, right - arm, bottom, paint);
            canvas.drawLine(right, bottom, right, bottom - arm, paint);
            paint.setColor(0xBB4FEEC6);
            paint.setStrokeWidth(Ui.dp(getContext(), 1));
            canvas.drawLine(left + Ui.dp(getContext(), 8), (top + bottom) / 2,
                    right - Ui.dp(getContext(), 8), (top + bottom) / 2, paint);
        }
    }
}
