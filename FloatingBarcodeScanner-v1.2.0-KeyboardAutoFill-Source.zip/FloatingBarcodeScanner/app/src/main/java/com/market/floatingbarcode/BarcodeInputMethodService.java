package com.market.floatingbarcode;

import android.content.ComponentName;
import android.content.Context;
import android.graphics.Color;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Optional barcode-only keyboard.  Explicitly chosen by the user in system keyboard picker.
 * No accessibility permission, keyboard contents collection, key logging, or network use.
 * The scanner can only insert into the editor that currently owns the IME connection.
 */
public final class BarcodeInputMethodService extends InputMethodService {
    private static volatile BarcodeInputMethodService instance;
    private volatile EditorInfo activeEditor;
    private TextView state;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override public View onCreateInputView() {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.HORIZONTAL);
        v.setGravity(Gravity.CENTER_VERTICAL);
        v.setPadding(Ui.dp(this, 10), Ui.dp(this, 7), Ui.dp(this, 10), Ui.dp(this, 7));
        v.setBackgroundColor(Ui.NAVY);
        state = Ui.text(this, "条码键盘 · 请使用悬浮扫码", 12, Ui.WHITE, true);
        v.addView(state, new LinearLayout.LayoutParams(0, Ui.dp(this, 38), 1));

        TextView repeat = Ui.button(this, "填入上次条码", Ui.BLUE, Color.WHITE);
        repeat.setTextSize(12);
        repeat.setOnClickListener(w -> {
            String code = BarcodeStore.getLast(this);
            boolean done = insertBarcode(this, code);
            if (state != null) state.setText(done ? "✓ 已填入条码" : "请先点选普通商品搜索框");
        });
        v.addView(repeat, new LinearLayout.LayoutParams(Ui.dp(this, 112), Ui.dp(this, 38)));
        return v;
    }

    @Override public void onStartInput(EditorInfo attribute, boolean restarting) {
        super.onStartInput(attribute, restarting);
        activeEditor = attribute;
        if (state != null) state.setText("条码键盘 · 扫码即可自动输入");
    }

    @Override public void onFinishInput() {
        activeEditor = null;
        super.onFinishInput();
    }

    @Override public void onDestroy() {
        activeEditor = null;
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public static boolean isSelected(Context context) {
        String current = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        String wanted = new ComponentName(context, BarcodeInputMethodService.class).flattenToString();
        return wanted.equals(current) ||
                (context.getPackageName() + "/.BarcodeInputMethodService").equals(current);
    }

    /** Returns false if no editor is focused, if password field, or if not selected as IME. */
    public static boolean insertBarcode(Context context, String code) {
        if (code == null || !code.matches("[0-9]+") || !isSelected(context)) return false;
        BarcodeInputMethodService service = instance;
        if (service == null || service.activeEditor == null) return false;
        EditorInfo editor = service.activeEditor;
        int variation = editor.inputType & InputType.TYPE_MASK_VARIATION;
        int cls = editor.inputType & InputType.TYPE_MASK_CLASS;
        if (cls == InputType.TYPE_CLASS_TEXT &&
                (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                 variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                 variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD)) return false;
        if (cls == InputType.TYPE_CLASS_NUMBER &&
                (editor.inputType & InputType.TYPE_NUMBER_VARIATION_PASSWORD) == InputType.TYPE_NUMBER_VARIATION_PASSWORD) return false;
        InputConnection connection = service.getCurrentInputConnection();
        if (connection == null) return false;
        try {
            connection.beginBatchEdit();
            boolean inserted = connection.commitText(code, 1);
            connection.endBatchEdit();
            if (service.state != null) service.state.setText(inserted ? "✓ 已自动输入 " + code : "自动输入失败，可手动粘贴");
            return inserted;
        } catch (RuntimeException e) {
            return false;
        }
    }
}
